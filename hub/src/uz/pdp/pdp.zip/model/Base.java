package uz.pdp.model;

public class Base {
    protected int id;
    protected String name;
    protected boolean isInActive;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isInActive() {
        return isInActive;
    }

    public void setInActive(boolean inActive) {
        isInActive = inActive;
    }
}
