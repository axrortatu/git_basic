package uz.pdp.model;

public class Merchant extends Base{
    private int gatewayMerchantId;

    public int getGatewayMerchantId() {
        return gatewayMerchantId;
    }

    public void setGatewayMerchantId(int gatewayMerchantId) {
        this.gatewayMerchantId = gatewayMerchantId;
    }
}
