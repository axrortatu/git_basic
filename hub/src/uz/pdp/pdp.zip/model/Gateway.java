package uz.pdp.model;

public class Gateway extends Base{

}
