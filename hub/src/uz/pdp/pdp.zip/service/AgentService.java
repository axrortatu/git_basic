package uz.pdp.service;

import uz.pdp.model.Agent;

import java.util.UUID;

public class AgentService {
    private Agent[] agents;
    private int index = 0;

    public AgentService(int size) {
        this.agents = new Agent[size];
    }

    public AgentService() {
    }

    public boolean addAgent(Agent agent) {
        this.agents[index++] = agent;

        return true;
    }

    public boolean deleteAgent(int agentId) {
        int var1 = 0;
        for (Agent agent : agents) {
            if (agent != null) {
                if (agent.getId() == agentId) {
                    agent.setInActive(true);
                    this.agents[var1] = agent;
                    return true;
                }
            }
            var1++;
        }
        return false;
    }

    public Agent getAgent(int agentId) {
        for (Agent agent : agents) {
            if (agent != null) {
                if (agent.getId() == agentId) {
                    return agent;
                }
            }
        }
        return null;
    }

}
