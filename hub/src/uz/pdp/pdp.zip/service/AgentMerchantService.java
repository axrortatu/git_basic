package uz.pdp.service;

import uz.pdp.model.Agent;
import uz.pdp.model.AgentMerchant;

public class AgentMerchantService {

    private AgentMerchant[] agentMerchants;
    private int index = 0;

    public AgentMerchantService(int size){
        agentMerchants = new AgentMerchant[size];
    }

    // agent merchantni qoshadi
    public int addAgentMerchant(AgentMerchant agentMerchant, AgentService agentService){
        Agent agent = agentService.getAgent(agentMerchant.getAgentId()); // agentni tekshiramiz
        if (agent == null) {
            return -5; // agar agent topilmasa -5 qaytaramiz
        }

        agentMerchants[index ++] = agentMerchant; // agent merchantni qo'shdik
        return 0; // success
    }

    // bu method bitta agent merchantlarini ro'yxatini olib beradi
    public AgentMerchant[] getAgentMerchants(int agentId){
        int cnt = 0;

        for (AgentMerchant agentMerchant: agentMerchants) {
            if (agentMerchant != null){
                if (agentMerchant.getAgentId() == agentId){
                    cnt ++;
                }
            }
        }
        AgentMerchant[] agentMerchantList = new AgentMerchant[cnt];
        cnt = 0;
        for (AgentMerchant agentMerchant: agentMerchants) {
            if (agentMerchant != null){
                if (agentMerchant.getAgentId() == agentId){
                    agentMerchantList[cnt ++] = agentMerchant;
                }
            }
        }
        return agentMerchantList;
    }



}
