package uz.pdp.service;

import uz.pdp.model.Gateway;
import uz.pdp.model.GatewayMerchant;

public class GatewayMerchantService {
    private GatewayMerchant[] gatewayMerchants;
    private int index = 0;

    public GatewayMerchantService(int size){
        gatewayMerchants = new GatewayMerchant[size];
    }

    public int addGatewayMerchant(GatewayMerchant gatewayMerchant, GatewayService gatewayService){

        Gateway gateway = gatewayService.getGateway(gatewayMerchant.getGatewayId());
        if (gateway == null){
            return -5;
        }

        gatewayMerchants[index ++] = gatewayMerchant; // Gateway merchantni qo'shdik
        return 0; // success
    }

    // bu method bitta gateway merchantlarini ro'yxatini olib beradi
    public GatewayMerchant[] getGatewayMerchants(int gatewayId){
        int cnt = 0;

        for (GatewayMerchant gatewayMerchant: gatewayMerchants) {
            if (gatewayMerchant != null){
                if (gatewayMerchant.getGatewayId() == gatewayId){
                    cnt ++;
                }
            }
        }
        GatewayMerchant[] gatewayMerchantList = new GatewayMerchant[cnt];
        cnt = 0;
        for (GatewayMerchant gatewayMerchant: gatewayMerchants) {
            if (gatewayMerchant != null){
                if (gatewayMerchant.getGatewayId() == gatewayId){
                    gatewayMerchantList[cnt ++] = gatewayMerchant;
                }
            }
        }
        return gatewayMerchantList;
    }


    public GatewayMerchant getGatewayMerchant(int merchantId){
        for (GatewayMerchant gatewayMerchant: gatewayMerchants) {
            if (gatewayMerchant != null) {
                if (gatewayMerchant.getMerchantId() == merchantId) {
                    return gatewayMerchant;
                }
            }
        }
        return null;
    }

}
