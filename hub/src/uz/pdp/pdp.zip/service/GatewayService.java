package uz.pdp.service;

import uz.pdp.model.Gateway;

public class GatewayService {

    private Gateway[] gateways;
    private int index = 0;

    public GatewayService(int size) {
        this.gateways = new Gateway[size];
    }

    public GatewayService() {
    }

    public boolean addGateway(Gateway gateway) {
        this.gateways[index++] = gateway;

        return true;
    }

    public boolean deleteGateway(int gatewayId) {
        int var1 = 0;
        for (Gateway gateway : gateways) {
            if (gateway != null) {
                if (gateway.getId() == gatewayId) {
                    gateway.setInActive(true);
                    this.gateways[var1] = gateway;
                    return true;
                }
            }
            var1++;
        }
        return false;
    }

    public Gateway getGateway(int gatewayId) {
        for (Gateway gateway : gateways) {
            if (gateway != null) {
                if (gateway.getId() == gatewayId) {
                    return gateway;
                }
            }
        }
        return null;
    }
}
